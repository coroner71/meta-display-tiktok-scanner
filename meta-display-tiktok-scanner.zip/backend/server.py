import asyncio
import json
import os
from contextlib import suppress
from typing import Any

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from TikTokLive import TikTokLiveClient
from TikTokLive.events import CommentEvent, ConnectEvent, DisconnectEvent, GiftEvent, LikeEvent, RoomUserSeqEvent


TIKTOK_UNIQUE_ID = os.environ.get("TIKTOK_UNIQUE_ID", "@daroodkanool10")

app = FastAPI(title="TikTokLive bridge")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["GET"],
    allow_headers=["*"],
)

event_queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=200)
client: TikTokLiveClient | None = None
client_task: asyncio.Task | None = None


async def publish(event: dict[str, Any]) -> None:
    if event_queue.full():
        with suppress(asyncio.QueueEmpty):
            event_queue.get_nowait()

    await event_queue.put(event)


def build_client() -> TikTokLiveClient:
    live_client = TikTokLiveClient(unique_id=TIKTOK_UNIQUE_ID)

    @live_client.on(ConnectEvent)
    async def on_connect(event: ConnectEvent) -> None:
        await publish({"type": "connect", "message": f"Connected to @{event.unique_id}"})

    @live_client.on(DisconnectEvent)
    async def on_disconnect(_: DisconnectEvent) -> None:
        await publish({"type": "disconnect", "message": "Disconnected from TikTok LIVE"})

    @live_client.on(CommentEvent)
    async def on_comment(event: CommentEvent) -> None:
        await publish({
            "type": "comment",
            "user": event.user.nickname,
            "message": event.comment,
        })

    @live_client.on(LikeEvent)
    async def on_like(event: LikeEvent) -> None:
        await publish({
            "type": "like",
            "user": event.user.nickname,
            "count": getattr(event, "count", 1),
        })

    @live_client.on(GiftEvent)
    async def on_gift(event: GiftEvent) -> None:
        await publish({
            "type": "gift",
            "user": event.user.nickname,
            "gift": event.gift.name,
            "count": event.repeat_count,
        })

    @live_client.on(RoomUserSeqEvent)
    async def on_viewers(event: RoomUserSeqEvent) -> None:
        await publish({
            "type": "viewers",
            "count": event.total_user_count,
        })

    return live_client


@app.on_event("startup")
async def startup() -> None:
    global client, client_task
    client = build_client()
    client_task = asyncio.create_task(client.start(fetch_room_info=True))
    await publish({"type": "startup", "message": f"Listening for {TIKTOK_UNIQUE_ID}"})


@app.on_event("shutdown")
async def shutdown() -> None:
    if client:
        await client.disconnect()

    if client_task:
        client_task.cancel()


@app.get("/health")
async def health() -> dict[str, Any]:
    return {
        "ok": True,
        "unique_id": TIKTOK_UNIQUE_ID,
        "connected": bool(client and client.connected),
    }


@app.get("/events")
async def events() -> StreamingResponse:
    async def stream():
        while True:
            event = await event_queue.get()
            yield f"data: {json.dumps(event)}\n\n"

    return StreamingResponse(stream(), media_type="text/event-stream")
