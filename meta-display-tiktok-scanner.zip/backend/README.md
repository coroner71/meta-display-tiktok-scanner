# TikTokLive Bridge

This optional backend uses `isaackogan/TikTokLive` to listen to TikTok LIVE events and expose them to the glasses web app over Server-Sent Events.

It does not provide the TikTok video stream. TikTokLive is an unofficial reverse-engineered library for livestream events such as comments, likes, gifts, joins, and room state.

## Run

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
TIKTOK_UNIQUE_ID=@daroodkanool10 uvicorn server:app --host 0.0.0.0 --port 8000
```

## Deploy

Deploy this folder to a Python host such as Render, Railway, Fly.io, or a VPS.

Then open the web app with:

```text
https://your-glasses-app.example/?events=https%3A%2F%2Fyour-backend.example%2Fevents
```

The glasses page will show live comments/gifts/viewer events in the TikTok LIVE Signals panel.
